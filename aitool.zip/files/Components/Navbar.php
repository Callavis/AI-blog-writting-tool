<?php

if (isset($_SESSION['access_token'])) {
    $name = "Admin";
} else {
    $name = "";
}

?>

<nav class="navbar is-flex is-primary is-justify-content-space-between" role="navigation" aria-label="main navigation">


    <div class="navbar-brand">
        <a class="navbar-item" href="<?php echo webUrl; ?>">
            <img src="https://i.imgur.com/IRoHPLy.png" width="30" height="150">
        </a>
    </div>

    <?php

    echo  $name !== "" ?

        '<div class="is-flex">
            <p class="mx-2 my-3">'. $name .'</p>
            <a class="navbar-item logout-btn" href="logout">
                <img src="https://i.imgur.com/7EQtrFe.png" width="30" height="150">
            </a>
        </div>'

        :

        ""

    ?>


    <!-- <div class="is-flex ">

      

    </div> -->

</nav>