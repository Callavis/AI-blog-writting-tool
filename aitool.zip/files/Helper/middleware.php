<?php

function middleware($reqUri)
{

    if ($reqUri === "/") {
        return;
    }

    if ($reqUri !== "/") {

        if (!isset($_SESSION['access_token'])) {

            redirect("/");
           
        }
    }

    if ($reqUri === "/") {

        if (isset($_SESSION['access_token'])) {

            redirect("/home");
           
        }
    }
   

}
