<?php

//without end slash '/'
const webUrl = "https://yourweb.com";

const token = "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";

const password = "123";

?>
