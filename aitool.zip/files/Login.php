<?php

if (isset($_SESSION['access_token'])) {
    redirect("/home");
}

$error = "";

if (isset($_GET['pass']) && $_GET['pass'] === password) {
    $_SESSION['access_token'] = password;
    redirect("/home");
}

if(isset($_GET['pass']) && $_GET['pass'] !== password){
    $error = "Password is wrong";
}


?>

<?php

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>AI Writing Tool | Login</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.3/css/bulma.min.css">
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
    <script src="https://cdn.ckeditor.com/ckeditor5/33.0.0/classic/ckeditor.js"></script>
    <link rel="stylesheet" href="assets/style.css">

</head>

<body>

    <?php

    include("Components/Navbar.php");

    ?>

    <section class="section">

        <div class="is-flex is-align-items-center is-flex-wrap-wrap is-justify-content-center" style="min-height: 85vh;">

            <form action="" method="GET">

                    <div class="field">
                        <label class="label">Password</label>
                        <input name="pass" class="input is-success" type="text" placeholder="Password">
                    </div>

                    <p class="help is-danger my-2"><?php echo $error ?></p>

                    <div class="field">
                        <div class="control">
                            <button style="width: 100%;" class="button is-primary">Submit</button>
                        </div>
                    </div>

            </form>


        </div>

    </section>

</body>



</html>