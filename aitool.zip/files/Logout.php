<?php

unset($_SESSION['access_token']);
unset($_SESSION['first_name']);

redirect("/");

?>