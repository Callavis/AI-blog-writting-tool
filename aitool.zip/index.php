<?php


//start session on web page
session_start();

include "files/Helper/Route.php";
include "files/Helper/middleware.php";
include "files/Helper/Support.php";
include "files/Helper/Variables.php";

cors();

$route = new Route();

$route->get("/", "files/Login.php");

$route->get("/home", "files/Home.php");

$route->get("/content", "files/Content.php");

$route->get("/articlewriter", "files/ArticleWriter.php");

$route->get("/rewriter", "files/Rewriter.php");

$route->get("/improve", "files/Improve.php");

$route->get("/answers", "files/Answers.php");

$route->get("/playground", "files/Playground.php");

$route->get("/logout", "files/Logout.php");

$route->get("/summarize", "files/Summarize.php");


//api
$route->post("/contentapi", "files/API/ContentApi.php");

$route->post("/articleapi", "files/API/ArticleApi.php");

$route->post("/rewriterapi", "files/API/RewriterApi.php");

$route->post("/improveapi", "files/API/ImproveApi.php");

$route->post("/answersapi", "files/API/AnswersApi.php");

$route->post("/playgroundapi", "files/API/PlaygroundApi.php");

$route->post("/summarizeapi", "files/API/SummarizeApi.php");

$route->notFound("404.php");
